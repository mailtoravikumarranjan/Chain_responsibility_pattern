﻿

using Chain_Responsblity_Principle;

var seniorManager = new SeniorManager();
var vicePresident = new VicePresident();
var ceo = new CEO();

seniorManager.SetSupervisor(vicePresident);
vicePresident.SetSupervisor(ceo);


var expenceReport = new ExpenseReport("John","Monitor",435);
Console.WriteLine(expenceReport);
seniorManager.ApproveRequest(expenceReport);
Console.WriteLine("=====================================");

expenceReport = new ExpenseReport("John", "Travel", 960);
Console.WriteLine(expenceReport);
seniorManager.ApproveRequest(expenceReport);
Console.WriteLine("=====================================");

expenceReport = new ExpenseReport("John", "Laptop", 4800);
Console.WriteLine(expenceReport);
seniorManager.ApproveRequest(expenceReport);
Console.WriteLine("=====================================");

expenceReport = new ExpenseReport("John", "AWS Training ", 6800);
Console.WriteLine(expenceReport);
seniorManager.ApproveRequest(expenceReport);