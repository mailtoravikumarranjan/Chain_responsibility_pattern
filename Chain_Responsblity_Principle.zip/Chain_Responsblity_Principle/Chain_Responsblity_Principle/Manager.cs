﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chain_Responsblity_Principle
{
    internal record ExpenseReport(string Name,string ExpenceType, decimal Amount);
    internal interface IManager
    {
        void SetSupervisor(IManager manager);
        void ApproveRequest(ExpenseReport expenceReport);
    }

    internal class SeniorManager : IManager
    {
        private IManager _supervisor;
        public void SetSupervisor(IManager manager)
        {
            _supervisor = manager;
        }

        public void ApproveRequest(ExpenseReport expenceReport)
        {
            if (expenceReport.Amount < 500)
            {
                Console.WriteLine($"Senior Manager approved the request of {expenceReport.Name} for {expenceReport.ExpenceType} of amount ${expenceReport.Amount}");
            }
            else
            {
                _supervisor.ApproveRequest(expenceReport);
            }
        }
    }
    internal class VicePresident : IManager
    {
        private IManager _supervisor;
        public void SetSupervisor(IManager manager)
        {
            _supervisor = manager;
        }

        public void ApproveRequest(ExpenseReport expenceReport)
        {
            if (expenceReport.Amount < 1000)
            {
                Console.WriteLine($"Vice persident Manager approved the request of {expenceReport.Name} for {expenceReport.ExpenceType} of amount ${expenceReport.Amount}");
            }
            else
            {
                _supervisor.ApproveRequest(expenceReport);
            }
        }
    }
    internal class CEO : IManager
    {
        private IManager _supervisor;
        public void SetSupervisor(IManager manager)
        {
            _supervisor = manager;
        }

        public void ApproveRequest(ExpenseReport expenceReport)
        {
            if (expenceReport.Amount < 5000)
            {
                Console.WriteLine($"CEO approved the request of {expenceReport.Name} for {expenceReport.ExpenceType} of amount ${expenceReport.Amount}");
            }
            else
            {
                Console.WriteLine("Not Approved");
            }
        }
    }
}
